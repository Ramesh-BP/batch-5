public class Demo {
    static int a=10;
    static  void add(){
        System.out.println(a+a);
    }
    public static void main(String[] args) {
        add();
        System.out.println(a);
    }
}
 